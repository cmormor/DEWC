import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export const CrearEmpleado = ({ onCrear }) => {
    const [empleado, setEmpleado] = useState({
        id: '',
        first_name: '',
        last_name: '',
        email: '',
        address: '',
        nafiliacion: '',
        antiguedad: '',
        job: '',
    });

    const navigate = useNavigate();

    const handleChange = (e) => {
        const { name, value } = e.target;
        setEmpleado((prevState) => ({
            ...prevState,
            [name]: value,
        }));
    };

    const handleSubmit = (e) => {
        e.preventDefault();
        const nuevoEmpleado = { ...empleado, id: Date.now() };
        onCrear(nuevoEmpleado);
        setEmpleado({
            id: '',
            first_name: '',
            last_name: '',
            email: '',
            address: '',
            nafiliacion: '',
            antiguedad: '',
            job: '',
        });
        navigate('/');
    };

    return (
        <div>
            <h2>Añadir Nuevo Empleado</h2>
            <form onSubmit={handleSubmit}>
                <label>
                    Nombre:
                    <input
                        type="text"
                        name="first_name"
                        value={empleado.first_name}
                        onChange={handleChange}
                    />
                </label>
                <label>
                    Apellido:
                    <input
                        type="text"
                        name="last_name"
                        value={empleado.last_name}
                        onChange={handleChange}
                    />
                </label>
                <label>
                    Email:
                    <input
                        type="email"
                        name="email"
                        value={empleado.email}
                        onChange={handleChange}
                    />
                </label>
                <label>
                    Dirección:
                    <input
                        type="text"
                        name="address"
                        value={empleado.address}
                        onChange={handleChange}
                    />
                </label>
                <label>
                    Afiliación:
                    <input
                        type="text"
                        name="nafiliacion"
                        value={empleado.nafiliacion}
                        onChange={handleChange}
                    />
                </label>
                <label>
                    Antigüedad:
                    <input
                        type="number"
                        name="antiguedad"
                        value={empleado.antiguedad}
                        onChange={handleChange}
                    />
                </label>
                <label>
                    Trabajo:
                    <input
                        type="text"
                        name="job"
                        value={empleado.job}
                        onChange={handleChange}
                    />
                </label>
                <button type="submit">Guardar Empleado</button>
            </form>
        </div>
    );
};
