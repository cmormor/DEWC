import React, { useState } from "react";

export const BuscarEmpleado = ({ empleados, onFiltrar }) => {
    const [termino, setTermino] = useState("");

    const handleChange = (e) => {
        const valor = e.target.value;
        setTermino(valor);
    
        const empleadosFiltrados = empleados.filter((empleado) =>
            Object.values(empleado).some((campo) =>
                campo.toString().toLowerCase().includes(valor.toLowerCase())
            )
        );
        onFiltrar(empleadosFiltrados);
    };
    

    return (
        <div>
            <input
                type="text"
                placeholder="Buscar empleado..."
                value={termino}
                onChange={handleChange}
            />
        </div>
    );
};
