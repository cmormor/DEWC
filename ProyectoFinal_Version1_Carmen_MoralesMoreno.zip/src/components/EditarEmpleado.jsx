import React, { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";

export const EditarEmpleado = ({ empleado, onGuardar }) => {
    const [formData, setFormData] = useState({});

    const navigate = useNavigate();

    useEffect(() => {
        if (empleado) {
            setFormData(empleado);
        }
    }, [empleado]);

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({
            ...formData,
            [name]: value,
        });
    };

    const handleGuardar = () => {
        onGuardar(formData);
        navigate("/");
    };

    return (
        <>
            <h2>EDITAR EMPLEADO</h2>
            <form>
                <div>
                    <label>Nombre:</label>
                    <input
                        type="text"
                        name="first_name"
                        value={formData.first_name || ""}
                        onChange={handleChange}
                    />
                </div>
                <div>
                    <label>Apellido:</label>
                    <input
                        type="text"
                        name="last_name"
                        value={formData.last_name || ""}
                        onChange={handleChange}
                    />
                </div>
                <div>
                    <label>Email:</label>
                    <input
                        type="email"
                        name="email"
                        value={formData.email || ""}
                        onChange={handleChange}
                    />
                </div>
                <div>
                    <label>Dirección:</label>
                    <input
                        type="text"
                        name="address"
                        value={formData.address || ""}
                        onChange={handleChange}
                    />
                </div>
                <div>
                    <label>Afiliación SS:</label>
                    <input
                        type="text"
                        name="nafiliacionss"
                        value={formData.nafiliacionss || ""}
                        onChange={handleChange}
                    />
                </div>
                <div>
                    <label>Antigüedad:</label>
                    <input
                        type="number"
                        name="antiguedad"
                        value={formData.antiguedad || ""}
                        onChange={handleChange}
                    />
                </div>
                <div>
                    <label>Trabajo:</label>
                    <input
                        type="text"
                        name="job"
                        value={formData.job || ""}
                        onChange={handleChange}
                    />
                </div>
                <button type="button" onClick={handleGuardar}>
                    Guardar
                </button>
                <Link to="/">
                    <button type="button">Cancelar</button>
                </Link>
            </form>
        </>
    );
};
