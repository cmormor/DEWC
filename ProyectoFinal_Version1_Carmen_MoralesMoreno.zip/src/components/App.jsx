import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Route, Routes, Link } from 'react-router-dom';
import { arrayEmpleados } from '../data/empleados';
import { ListarEmpleado } from './ListarEmpleado';
import { EditarEmpleado } from './EditarEmpleado';
import { BuscarEmpleado } from './BuscarEmpleado';
import { CrearEmpleado } from './CrearEmpleado';

export const App = () => {
    const [empleados, setEmpleados] = useState(arrayEmpleados);
    const [empleadoEnEdicion, setEmpleadoEnEdicion] = useState(null);
    const [empleadosFiltrados, setEmpleadosFiltrados] = useState(arrayEmpleados);

    const seleccionarEmpleadoParaEdicion = (empleado) => {
        setEmpleadoEnEdicion(empleado);
    };

    const guardarEmpleadoEditado = (empleadoEditado) => {
        setEmpleados(
            empleados.map((empleado) =>
                empleado.id === empleadoEditado.id ? empleadoEditado : empleado
            )
        );
        setEmpleadosFiltrados(
            empleadosFiltrados.map((empleado) =>
                empleado.id === empleadoEditado.id ? empleadoEditado : empleado
            )
        );
    };

    const agregarEmpleado = (nuevoEmpleado) => {
        setEmpleados((prevEmpleados) => [...prevEmpleados, nuevoEmpleado]);
        setEmpleadosFiltrados((prevEmpleados) => [...prevEmpleados, nuevoEmpleado]);
    };

    const eliminarEmpleado = (id) => {
        const empleadosActualizados = empleados.filter((empleado) => empleado.id !== id);
        setEmpleados(empleadosActualizados);
        setEmpleadosFiltrados(empleadosActualizados);
    };
    

    const filtrarEmpleados = (empleadosFiltrados) => {
        setEmpleadosFiltrados(empleadosFiltrados);
    };

    useEffect(() => {
        setEmpleados(arrayEmpleados);
        setEmpleadosFiltrados(arrayEmpleados);
    }, []);

    return (
        <Router>
            <h1>GESTIÓN DE EMPLEADOS TechSolutions!</h1>
            <div id='opciones'>
                <BuscarEmpleado empleados={empleados} onFiltrar={filtrarEmpleados} />
                <button>
                    <Link to="/crear">Añadir Empleado</Link>
                </button>
            </div>
            <Routes>
                <Route
                    path="/"
                    element={
                        <ListarEmpleado
                            empleados={empleadosFiltrados}
                            onEditar={seleccionarEmpleadoParaEdicion}
                            onEliminar={eliminarEmpleado}
                        />
                    }
                />
                <Route
                    path="/editar"
                    element={
                        <EditarEmpleado
                            empleado={empleadoEnEdicion}
                            onGuardar={guardarEmpleadoEditado}
                        />
                    }
                />
                <Route
                    path="/crear"
                    element={<CrearEmpleado onCrear={agregarEmpleado} />}
                />
            </Routes>
        </Router>
    );
};
